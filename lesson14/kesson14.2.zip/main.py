from student import Student
from group import Group
from exceptions import TooManyStudentsError

def main():
    group = Group("PD1")

    try:
        for i in range(11):
            student = Student("Male", 20 + i, f"Name{i}", f"Surname{i}", f"AN14{i}")
            group.add_student(student)

    except TooManyStudentsError as e:
        print(f"Виняток: {e}")

    print("\nПоточний склад групи:")
    print(group)

    assert group.find_student("Surname0") == Student("Male", 20, "Name0", "Surname0", "AN140")
    assert group.find_student("NotExist") is None

    print("\nПошук:")
    print(group.find_student("Surname0"))
    print(group.find_student("NotExist"))

    print("\nВидалення:")
    group.delete_student("Surname0")
    print(group)

    group.delete_student("Surname0")

if __name__ == "__main__":
    main()
