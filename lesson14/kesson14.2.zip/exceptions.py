class TooManyStudentsError(Exception):
    """Користувацький виняток для перевищення кількості студентів у групі."""
    def __init__(self, message: str = "У групі не може бути більше 10 студентів") -> None:
        super().__init__(message)
